import { useState } from 'react';

// components
import Filter from '../../components/Filter';
import QueryList from '../../components/QueryList';

// styles
import '../dashboard/Dashboard.css';

// database
import Queries from '../../database/QueryData';

// context
import { useGlobalContext } from '../../Context';

export default function Dashboard() {
  const { user } = useGlobalContext();

  const [filter, setFilter] = useState('all');
  const filterList = ['all', 'hostel', 'department', 'quarters', 'other'];

  const [secondFilter, setSecondFilter] = useState('all');
  const secondFilterList = ['all', 'accepted', 'rejected'];

  const changeFilter = (newFilter) => {
    setFilter(newFilter);
  };

  const changeSecondFilter = (newFilter) => {
    setSecondFilter(newFilter);
  };

  const documents = user
    ? user.adminType !== 'student'
      ? Queries.filter((query) => query.type === user.adminType)
      : Queries.filter((query) => query.raisedBy === user.userName)
    : null;

  console.log(documents);

  const queries = documents
    ? documents.filter((document) => {
        switch (filter) {
          case 'all':
            return true;
          case 'hostel':
          case 'department':
          case 'quarters':
          case 'other':
            return document.category === filter;
          default:
            return true;
        }
      })
    : null;

  const queries_upd = queries
    ? queries.filter((qu) => {
        if (qu.status !== 'pending') {
          return true;
        }
      })
    : null;

  const queries_filtered = queries_upd
    ? queries_upd.filter((query) => {
        switch (secondFilter) {
          case 'all':
            return true;
          case 'accepted':
          case 'rejected':
            return query.status === secondFilter;
          default:
            return true;
        }
      })
    : null;

  return (
    <div className="resolved">
      <h2 className="page-title">Resolved</h2>
      {queries_filtered && (
        <Filter changeFilter={changeFilter} filterList={filterList} />
      )}
      {queries_filtered && (
        <Filter
          changeFilter={changeSecondFilter}
          filterList={secondFilterList}
        />
      )}
      {queries_filtered && <QueryList queries={queries_filtered} />}
    </div>
  );
}
