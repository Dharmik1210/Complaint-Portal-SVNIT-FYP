import { Link } from 'react-router-dom';

// database
import { useGlobalContext } from '../../Context';

export default function QuerySummary({ query }) {
  const { user } = useGlobalContext();

  return (
    <div className="query">
      <div className="query-summary">
        <h2 className="query-type">{query.type}</h2>
        <p className="assigned-date">Query raised at {query.assignedDate}</p>
        <p className="details">Details : {query.details}</p>
        <h3 className="query-category">Location : {query.category}</h3>
        <h3 className="query-by">
          Raised by :{' '}
          <Link to={`/profile/${query.raisedBy}`}>{query.raisedBy}</Link>
        </h3>
      </div>
      {user.adminType === 'student' && <button className="btn">Delete</button>}
      {user.adminType !== 'student' && (
        <button className="btn">Solved / Declined</button>
      )}
    </div>
  );
}
