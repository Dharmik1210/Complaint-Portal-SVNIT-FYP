import { useParams } from 'react-router-dom';

// components
import QuerySummary from './QuerySummary';
import QueryComments from './QueryComments';

// styles
import './Query.css';

// database
import Queries from '../../database/QueryData';

export default function Query() {
  const { id } = useParams();

  const documents = Queries;

  const query = documents.filter((doc) => {
    return doc.id === parseInt(id);
  });

  return (
    <div className="query-details">
      <QuerySummary query={query[0]} />
      <QueryComments query={query[0]} />
    </div>
  );
}
