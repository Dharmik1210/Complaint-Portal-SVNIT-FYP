import { useState } from "react";
import { useNavigate } from "react-router-dom";

// styles
import "./Login.css";

// context
import { useGlobalContext } from "../../Context";

// database
import Users from "../../database/UserData";

export default function Login() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const { setUser } = useGlobalContext();
  const handleSubmit = (e) => {
    e.preventDefault();
    const uppercaseName = name.toUpperCase();
    console.log(uppercaseName);

    // matching users
    const matchingUser = Users.find((user) => {
      return user.userName === uppercaseName && user.password === password;
    });

    if (matchingUser) {
      setUser(matchingUser);

      // if (matchingUser.adminType === "student") {
      //   navigate("/");
      // } else {
      //   navigate("/admin");
      // }

      navigate("/");
    } else {
      window.alert("Invalid Credentials");
    }
  };

  return (
    <form className="login" onSubmit={handleSubmit}>
      <h2>Login</h2>
      <label>
        <span>UserName:</span>
        <input
          type="text"
          required
          onChange={(e) => setName(e.target.value)}
          value={name}
        />
      </label>
      <label>
        <span>Password:</span>
        <input
          type="password"
          required
          onChange={(e) => setPassword(e.target.value)}
          value={password}
        />
      </label>
      <button className="btn">Login</button>
    </form>
  );
}
