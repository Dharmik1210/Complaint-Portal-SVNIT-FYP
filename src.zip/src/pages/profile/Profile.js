import { useNavigate, useParams } from "react-router-dom";

// styles
import "./Profile.css";

// database
import users from "../../database/UserData";

// context
import { useGlobalContext } from "../../Context";

export default function Profile() {
  const { id } = useParams();
  const navigate = useNavigate();

  const { user: currentUser } = useGlobalContext();
  const user = users.filter((user) => user.userName === id);

  const updateHandler = () => {
    navigate("/update-profile", { state: user[0] });
  };

  return (
    <>
      <div className="profile-page">
        <div className="general-section">
          <h4>General Information</h4>
          <ul>
            <li>
              <span>Name : </span> {user[0].name}
            </li>
            <li>
              <span>Admission No : </span> {user[0].userName}
            </li>
            {/* <li>
              <span>Department : </span> {user1.department}
            </li> */}
            <li>
              <span>Stay : </span> {user[0].stay}
            </li>
          </ul>
        </div>

        <div className="contact-section">
          <h4>Contact Information</h4>
          <ul>
            <li>
              <span>Email :</span> {user[0].email}
            </li>
            <li>
              <span>Mobile No: </span> {user[0].mobile}
            </li>
          </ul>
        </div>
        {currentUser === user[0] && (
          <button className="btn" onClick={updateHandler}>
            Update Profile
          </button>
        )}
      </div>
    </>
  );
}
