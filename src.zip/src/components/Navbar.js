// import { Link } from 'react-router-dom';

// styles
import './Navbar.css';
import Logo from '../assets/NIT_Surat_Logo.svg';

// context
import { useGlobalContext } from '../Context';

export default function Navbar() {
  const { user, setUser } = useGlobalContext();

  return (
    <nav className="navbar">
      <ul>
        <li className="logo">
          <img src={Logo} alt="SVNIT logo" />
          <span>Web-based Complaint Portal</span>
        </li>

        {/* {!user && (
          <>
            <li>
              <Link to="/login">Login</Link>
            </li>
          </>
        )} */}
        {user && (
          <>
            <li>
              <button className="btn" onClick={() => setUser(null)}>
                Logout
              </button>
            </li>
          </>
        )}
      </ul>
    </nav>
  );
}
