const query1 = {
  id: 1,
  type: "CCC",
  category: "hostel",
  details:
    "Internet connection in Hostel A is unstable and needs immediate attention.",
  raisedBy: "U20CS002",
  assignedDate: "September 10, 2023 at 10:15:30 AM",
  status: "pending",
  comments: [
    {
      displayName: "Electricity Admin",
      content: "We will send a technician to investigate the issue.",
      createdAt: new Date(),
      id: Math.random(),
    },
    {
      displayName: "Electricity Admin",
      content: "Please ensure that the power supply to the router is stable.",
      createdAt: new Date(),
      id: Math.random(),
    },
  ],
};

const query2 = {
  id: 2,
  type: "Electricity",
  category: "department",
  details:
    "There is a power outage in the Computer Science department building.",
  raisedBy: "U20CS047",
  status: "pending",
  assignedDate: "September 11, 2023 at 3:45:00 PM",
  comments: [
    {
      displayName: "Electricity Admin",
      content: "We are aware of the power outage and are working on it.",
      createdAt: new Date(),
      id: Math.random(),
    },
    {
      displayName: "Electricity Admin",
      content:
        "Our team is on-site to investigate the issue. Please bear with us.",
      createdAt: new Date(),
      id: Math.random(),
    },
  ],
};

const query3 = {
  id: 3,
  type: "CCC",
  category: "quarters",
  details:
    "Unable to connect to the university's Wi-Fi network in the library.",
  raisedBy: "U20CS049",
  status: "pending",
  assignedDate: "September 12, 2023 at 9:30:15 AM",
  comments: [
    {
      displayName: "CCC Admin",
      content: "We will check the library's Wi-Fi access points for issues.",
      createdAt: new Date(),
      id: Math.random(),
    },
  ],
};

const query4 = {
  id: 4,
  type: "Electricity",
  category: "other",
  details:
    "There was a power surge in the laboratory, and some equipment got damaged.",
  raisedBy: "U20CS002",
  status: "rejected",
  assignedDate: "September 13, 2023 at 2:20:45 PM",
  comments: [],
};

const query5 = {
  id: 5,
  type: "CCC",
  category: "hostel",
  details:
    "Slow internet speed in the cafeteria is causing disruptions during online classes.",
  raisedBy: "U20CS047",
  status: "accepted",
  assignedDate: "September 14, 2023 at 11:10:00 AM",
  comments: [],
};

const query6 = {
  id: 6,
  type: "Electricity",
  category: "department",
  details:
    "A power outage is affecting the administration building's operations.",
  raisedBy: "U20CS049",
  status: "pending",
  assignedDate: "September 15, 2023 at 4:55:30 PM",
  comments: [],
};

const query7 = {
  id: 7,
  type: "CCC",
  category: "quarters",
  details:
    "The Wi-Fi signal in the student lounge is weak and frequently disconnects.",
  raisedBy: "U20CS002",
  assignedDate: "September 16, 2023 at 8:40:20 AM",
  status: "rejected",
  comments: [
    {
      displayName: "CCC Admin",
      content:
        "We will improve the access points in the student lounge for better connectivity.",
      createdAt: new Date(),
      id: Math.random(),
    },
  ],
};

const query8 = {
  id: 8,
  type: "Electricity",
  category: "other",
  details:
    "The circuit breaker in the chemistry lab tripped, and there's no power.",
  raisedBy: "U20CS047",
  status: "accepted",
  assignedDate: "September 17, 2023 at 01:05:10 PM",
  comments: [
    {
      displayName: "Electricity Admin",
      content:
        "We have reset the circuit breaker, and power should be restored shortly.",
      createdAt: new Date(),
      id: Math.random(),
    },
  ],
};

const query9 = {
  id: 9,
  type: "CCC",
  category: "hostel",
  details:
    "Unable to access online course materials due to network issues in the lecture hall.",
  raisedBy: "U20CS049",
  status: "pending",
  assignedDate: "September 18, 2023 at 10:30:45 AM",
  comments: [],
};

const query10 = {
  id: 10,
  type: "Electricity",
  category: "other",
  details:
    "The generator in the gymnasium stopped working, and there's no backup power.",
  raisedBy: "U20CS002",
  status: "accepted",
  assignedDate: "September 19, 2023 at 3:15:00 PM",
  comments: [],
};

const Queries = [
  query1,
  query2,
  query3,
  query4,
  query5,
  query6,
  query7,
  query8,
  query9,
  query10,
];

export default Queries;
