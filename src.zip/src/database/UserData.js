const user1 = {
  userName: "U20CS049",
  password: "U20CS049",
  name: "Patel Dharmik Hasmukhkumar",
  mobile: 9574539585,
  email: "dhpatel1210@gmail.com",
  stay: "Swami Bhavan",
  adminType: "student",
};

const user2 = {
  userName: "U20CS047",
  password: "U20CS047",
  name: "Meetkumar Gothi",
  mobile: 6353570473,
  email: "meetunpatel.0510@gmail.com",
  stay: "Swami Bhavan",
  adminType: "student",
};

const user3 = {
  userName: "U20CS002",
  password: "U20CS002",
  name: "Rashtrapal Doriya",
  mobile: 9081010117,
  email: "doriyarashtrapal@gmail.com",
  stay: "Swami Bhavan",
  adminType: "student",
};

const user4 = {
  userName: "CCCADMIN",
  password: "CCCAdmin",
  name: "CCC Admin",
  mobile: 9429222822,
  email: "cccadmin@gmail.com",
  stay: "NA",
  adminType: "CCC",
};

const user5 = {
  userName: "ElectricityADMIN",
  password: "ElectricityAdmin",
  name: "Electricity Admin",
  mobile: 6358475789,
  email: "electricityadmin@gmail.com",
  stay: "NA",
  adminType: "Electricity",
};

const users = [user1, user2, user3, user4, user5];

export default users;