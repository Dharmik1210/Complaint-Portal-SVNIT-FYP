import { useState } from 'react';

// styles
import './Filter.css';

export default function QueryFilter({ changeFilter, filterList }) {
  //default set to all as a filter type
  const [currentFilter, setCurrentFilter] = useState('all');

  //now onlclick event handler set filter as curr and also changeFilter from prop of parent element to newFilter
  const handleClick = (e) => {
    const newFilter = e.target.value;
    setCurrentFilter(newFilter);
    changeFilter(newFilter);
  };

  return (
    <div className="filter">
      <label htmlFor="filterSelect">Filter by: </label>
      <select id="filterSelect" value={currentFilter} onChange={handleClick}>
        {filterList.map((f) => (
          <option key={f} value={f}>
            {f}
          </option>
        ))}
      </select>
    </div>
  );
}
