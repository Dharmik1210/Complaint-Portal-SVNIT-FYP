import { NavLink } from 'react-router-dom';

// styles & images
import './Sidebar.css';
import ProfileIcon from '../assets/profile_icon.svg';
import DashboardIcon from '../assets/dashboard_icon.svg';
import ResolvedIcon from '../assets/resolved_icon.svg';
import AddIcon from '../assets/add_icon.svg';

// context
import { useState } from 'react';

export default function Sidebar() {
  // const { user } = useGlobalContext();
  // const userName = user ? user.userName : null;
  // const [isCollapsed, setIsCollapsed] = useState(false);

  // const toggleSidebar = () => {
  // setIsCollapsed(!isCollapsed);
  // };
  return (
    <div className="sidebar">
      <div className="sidebar-content">
        {/* <div className="toggle-button" onClick={toggleSidebar}> */}
        {/* <Bars3Icon className="h-1 w-1" /> Adjust the size as needed */}
        {/* </div> */}
        <div className="user">
          <p>Hi, U20CS049</p>
        </div>
        <nav className="links">
          <ul>
            <li>
              <NavLink exact to="/">
                <img src={DashboardIcon} alt="dashboard icon" />
                <span>Dashboard</span>
              </NavLink>
            </li>
            <li>
              <NavLink to="/resolved">
                <img src={ResolvedIcon} alt="resolved icon" />
                <span>Resolved</span>
              </NavLink>
            </li>
            <li>
              <NavLink to="/profile/U20CS049">
                <img src={ProfileIcon} alt="profile icon" />
                <span>My Profile</span>
              </NavLink>
            </li>

            <li>
              <NavLink to="/create">
                <img src={AddIcon} alt="add query icon" />
                <span>New Complaint</span>
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
}
