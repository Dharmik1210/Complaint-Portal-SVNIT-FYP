import { Link } from 'react-router-dom';

// styles
import './QueryList.css';

// database
// import { useGlobalContext } from '../Context';

export default function QueryList({ queries }) {
  // const { user } = useGlobalContext();

  return (
    <div className="query-list">
      {queries.length === 0 && <p>No complaint yet!</p>}
      {queries.map((query) => (
        <Link to={`/query/${query.id}`} key={query.id}>
          <h3>{query.type}</h3>
          <p>Raised on {query.assignedDate}</p>
          <h4>{query.category}</h4>
          {/* {user.adminType !== 'student' && ( */}
          <div className="query-by">
            <h4>
              Complaint raised by :{' '}
              <Link className="profile-link" to={`/profile/${query.raisedBy}`}>
                {query.raisedBy}
              </Link>
            </h4>
          </div>
          {/* )} */}
        </Link>
      ))}
    </div>
  );
}
