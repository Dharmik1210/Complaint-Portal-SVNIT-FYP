import { useState } from "react";
import { useNavigate } from "react-router-dom";

// styles
import "./Login.css";

export default function Login() {
  const navigate = useNavigate();
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(userName, password);
    navigate("/");
  };

  return (
    <form className="login" onSubmit={handleSubmit}>
      <h2>Login</h2>
      <label>
        <span>UserName:</span>
        <input
          type="text"
          required
          onChange={(e) => setUserName(e.target.value)}
          value={userName}
        />
      </label>
      <label>
        <span>Password:</span>
        <input
          type="password"
          required
          onChange={(e) => setPassword(e.target.value)}
          value={password}
        />
      </label>
      <button className="btn">Login</button>
    </form>
  );
}
