import { useState } from "react";
import Select from "react-select";

// styles
import "./Create.css";

const queryCategories = [
  { value: "CCC", label: "CCC" },
  { value: "electricity", label: "Electricity" },
];

const buildingCategories = [
  { value: "hostel", label: "Hostel" },
  { value: "department", label: "Department" },
  { value: "quarters", label: "Quarters" },
  { value: "other", label: "Other" },
];

export default function Create() {
  // form field values
  const [type, setType] = useState("");
  const [details, setDetails] = useState("");
  const [building, setBuilding] = useState("");
  const [roomNo, setRoomNo] = useState("");
  const [exactLocation, setExactLocation] = useState("");
  const [formError, setFormError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);

    if (!type) {
      setFormError("Please select a query type.");
      return;
    }

    if (!building) {
      setFormError("Please select a building.");
      return;
    }

    console.log(type, details, roomNo, exactLocation);
  };

  return (
    <div className="create-form">
      <h2 className="page-title">Raise a new Query</h2>
      <form onSubmit={handleSubmit}>
        <label>
          <span>Type:</span>
          <Select
            onChange={(option) => setType(option)}
            options={queryCategories}
          />
        </label>
        <label>
          <span>Query Details:</span>
          <textarea
            required
            onChange={(e) => setDetails(e.target.value)}
            value={details}
          ></textarea>
        </label>
        <label>
          <span>Building:</span>
          <Select
            onChange={(option) => setBuilding(option)}
            options={buildingCategories}
          />
        </label>
        <label>
          <span>Room No:</span>
          <input
            required
            onChange={(e) => setRoomNo(e.target.value)}
            value={roomNo}
          ></input>
        </label>
        <label>
          <span>exact Location:</span>
          <input
            required
            onChange={(e) => setExactLocation(e.target.value)}
            value={exactLocation}
          ></input>
        </label>

        <button className="btn">Raise Query</button>
        {formError && <p className="error">{formError}</p>}
      </form>
    </div>
  );
}
