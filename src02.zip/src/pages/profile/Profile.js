import { useNavigate, useParams } from "react-router-dom";

// styles
import "./Profile.css";

export default function Profile() {
  const { id } = useParams();
  const navigate = useNavigate();

  const user = {
    name: "",
    userName: "",
    stay: "",
    department: "",
    email: "",
    mobile: ""
  };

  const updateHandler = () => {
    navigate("/update-profile", { state: user });
  };

  return (
    <div className="profile-page">
      <div className="general-section">
        <h4>General Information</h4>
        <ul>
          <li>
            <span>Name : </span> {user.name}
          </li>
          <li>
            <span>Admission No : </span> {user.userName}
          </li>
          <li>
              <span>Department : </span> {user.department}
          </li>
          <li>
            <span>Stay : </span> {user.stay}
          </li>
        </ul>
      </div>

      <div className="contact-section">
        <h4>Contact Information</h4>
        <ul>
          <li>
            <span>Email :</span> {user.email}
          </li>
          <li>
            <span>Mobile No: </span> {user.mobile}
          </li>
        </ul>
      </div>
      <button className="btn" onClick={updateHandler}>
        Update Profile
      </button>
    </div>
  );
}
