import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

// styles
import './UpdateProfile.css';

export default function UpdateProfile() {
  const location = useLocation();
  const navigate = useNavigate();

  const user = {
    name: location.state.name,
    mobile: location.state.mobile,
    email: location.state.email,
    stay: location.state.stay
  };

  const [name, setName] = useState(user.name);
  const [mobile, setMobile] = useState(user.mobile);
  const [email, setEmail] = useState(user.email);
  const [stayInfo, setStayInfo] = useState(user.stay);

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate("/");
  };

  return (
    <form className="update-form" onSubmit={handleSubmit}>
      <h2>Update Profile</h2>
      <label>
        <span>Name:</span>
        <input
          type="text"
          required
          onChange={(e) => setName(e.target.value)}
          value={name}
        />
      </label>
      <label>
        <span>Mobile:</span>
        <input
          type="mobile"
          required
          onChange={(e) => setMobile(e.target.value)}
          value={mobile}
        />
      </label>
      <label>
        <span>email:</span>
        <input
          type="email"
          required
          onChange={(e) => setEmail(e.target.value)}
          value={email}
        />
      </label>
      <label>
        <span>Stay:</span>
        <input
          type="mobile"
          required
          onChange={(e) => setStayInfo(e.target.value)}
          value={stayInfo}
        />
      </label>
      <button className="btn">Update</button>
    </form>
  );
}
