import { useState } from 'react';

// components
import Filter from '../../components/Filter';
import QueryList from '../../components/QueryList';

// styles
import './Dashboard.css';

export default function Dashboard() {
  const [filter, setFilter] = useState('all');
  // const filterList = ['all', 'hostel', 'department', 'quarters', 'other'];
  const filterList = [
    {
      label: 'Main Filters',
      options: [
        { value: 'all', label: 'All' },
        { value: 'hostel', label: 'Hostel' },
        { value: 'department', label: 'Department' },
        { value: 'quarters', label: 'Quarters' },
        { value: 'other', label: 'Other' },
      ],
    },
    {
      label: 'Hostel Filters',
      options: [
        { value: 'A', label: 'Hostel A' },
        { value: 'B', label: 'Hostel B' },
        { value: 'C', label: 'Hostel C' },
      ],
    },
    {
      label: 'Department Filters',
      options: [
        { value: '1', label: 'Department 1' },
        { value: '2', label: 'Department 2' },
        { value: '3', label: 'Department 3' },
      ],
    },
    // Add more filter groups as needed
  ];

  const changeFilter = (newFilter) => {
    setFilter(newFilter);
  };

  // will fetch from database
  const documents = [];

  const queries = documents
    ? documents.filter((document) => {
        switch (filter) {
          case 'all':
            return true;
          case 'hostel':
          case 'department':
          case 'quarters':
          case 'other':
            return document.category === filter;
          default:
            return true;
        }
      })
    : null;

  return (
    <div className="dashboard">
      {/* <h2 className="page-title">Dashboard</h2> */}
      {queries && (
        <Filter filterList={filterList} changeFilter={changeFilter} />
      )}
      {queries && <QueryList queries={queries} />}
    </div>
  );
}
