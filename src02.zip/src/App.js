import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';

// styles
import './App.css';

// pages & components
import Navbar from './components/Navbar';
import Dashboard from './pages/dashboard/Dashboard';
import Admin from './pages/admin/Admin';
import Create from './pages/create/Create';
import Login from './pages/login/Login';
import Query from './pages/query/Query';
import Profile from './pages/profile/Profile';
import UpdateProfile from './pages/profile/UpdateProfile';
import Resolved from './pages/resolved/Resolved';
import Sidebar from './components/Sidebar';
//import 'bootstrap/dist/css/bootstrap.css';
// context
// import { useGlobalContext } from './Context';

function App() {
  // const { user } = useGlobalContext();

  return (
    <div className="App">
      <BrowserRouter>
        <Sidebar />
        <div className="container">
          <Navbar />
          {/* <div className="container"> */}
          <Routes>
            <Route exact path="/" element={<Dashboard />} />
            <Route exact path="/" element={<Admin />} />
            <Route path="/query/:id" element={<Query />} />
            <Route path="/profile/:id" element={<Profile />} />
            <Route path="/update-profile" element={<UpdateProfile />} />
            <Route path="/create" element={<Create />} />
            <Route path="/resolved" element={<Resolved />} />
            <Route path="/login" element={<Login />} />
          </Routes>
        </div>
        {/* </div> */}
      </BrowserRouter>
    </div>
  );
}

export default App;
