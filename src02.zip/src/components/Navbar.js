// styles
import './Navbar.css';

//SVNIT LOGO
import Logo from '../assets/NIT_Surat_Logo.svg';

// // context
// import { useGlobalContext } from '../Context';

export default function Navbar() {
  // const { user, setUser } = useGlobalContext();

  return (
    <nav className="navbar">
      <ul>
        <li className="logo">
          <img src={Logo} alt="SVNIT logo" />
          <span>Web-based Complaint Portal</span>
        </li>
        <li>
          <button className="btnlogout">Logout</button>
        </li>
      </ul>
    </nav>
  );
}
