import { useState } from 'react';

// styles
import './Filter.css';

export default function QueryFilter({ changeFilter, filterList }) {
  //default set to all as a filter type
  const [currentFilter, setCurrentFilter] = useState('all');
  const isValidFilterList = Array.isArray(filterList) && filterList.length > 0;
  //now onlclick event handler set filter as curr and also changeFilter from prop of parent element to newFilter
  const handleClick = (e) => {
    const newFilter = e.target.value;
    setCurrentFilter(newFilter);
    changeFilter(newFilter);
  };

  return (
    <div className="filter">
      <label htmlFor="filterSelect">Filter by : </label>
      <select id="filterSelect" value={currentFilter} onChange={handleClick}>
        {filterList.map((f) => (
          <optgroup key={f.label} label={f.label}>
            {f.options.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </optgroup>
        ))}
      </select>
    </div>
  );
}
