import { NavLink } from 'react-router-dom';
import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarFooter,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';
// styles & images
import './Sidebar.css';
import ProfileIcon from '../assets/profile_icon.svg';
import DashboardIcon from '../assets/dashboard_icon.svg';
import ResolvedIcon from '../assets/resolved_icon.svg';
import AddIcon from '../assets/add_icon.svg';

// context
import { useState } from 'react';

export default function Sidebar() {
  // const { user } = useGlobalContext();
  // const userName = user ? user.userName : null;
  // const [isCollapsed, setIsCollapsed] = useState(false);

  // const toggleSidebar = () => {
  // setIsCollapsed(!isCollapsed);
  // };

  return (
    // <div className="sidebar">
    //   <div className="sidebar-content">
    //     <div className="user">
    //       <p>Hi, U20CS049</p>
    //     </div>
    //     <nav className="links">
    //       <ul>
    //         <li>
    //           <NavLink exact to="/">
    //             <img src={DashboardIcon} alt="dashboard icon" />
    //             <span>Dashboard</span>
    //           </NavLink>
    //         </li>
    //         <li>
    //           <NavLink to="/resolved">
    //             <img src={ResolvedIcon} alt="resolved icon" />
    //             <span>Resolved</span>
    //           </NavLink>
    //         </li>
    //         <li>
    //           <NavLink to="/profile/U20CS049">
    //             <img src={ProfileIcon} alt="profile icon" />
    //             <span>My Profile</span>
    //           </NavLink>
    //         </li>

    //         <li>
    //           <NavLink to="/create">
    //             <img src={AddIcon} alt="add query icon" />
    //             <span>New Complaint</span>
    //           </NavLink>
    //         </li>
    //       </ul>
    //     </nav>
    //   </div>
    // </div>
    <div
      style={{
        // minWidth: '285px',
        // width: '285px',
        display: 'flex',
        height: '100vh',
        overflow: 'scroll initial',
      }}
      // className="sidebar"
    >
      <CDBSidebar textColor="#fff" backgroundColor="#199dcc" minWidth="285px">
        <div className="user">
          <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
            <a href="/" className="user" style={{ color: 'inherit' }}>
              HI, U20CS049
            </a>
          </CDBSidebarHeader>
        </div>

        <CDBSidebarContent className="sidebar-content">
          <CDBSidebarMenu>
            <NavLink exact to="/" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="columns">Dashboard</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/resolved" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="check-circle">
                Resolved
              </CDBSidebarMenuItem>
            </NavLink>
            <NavLink
              exact
              to="/profile/U20CS049"
              activeClassName="activeClicked"
            >
              <CDBSidebarMenuItem icon="user">Profile</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/create" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="plus">New Complaint</CDBSidebarMenuItem>
            </NavLink>
          </CDBSidebarMenu>
        </CDBSidebarContent>

        {/* <CDBSidebarFooter style={{ textAlign: 'center' }}>
          <div
            style={{
              padding: '20px 5px',
            }}
          >
            Sidebar Footer
          </div>
        </CDBSidebarFooter> */}
      </CDBSidebar>
    </div>
  );
}
