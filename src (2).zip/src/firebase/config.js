import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import "firebase/compat/auth";
import "firebase/compat/storage";

const firebaseConfig = {
  apiKey: "AIzaSyB1d4UzKNHG4kair3GLD0mSiaEOwggYQ8M",
  authDomain: "complaint-portal-cce06.firebaseapp.com",
  projectId: "complaint-portal-cce06",
  storageBucket: "complaint-portal-cce06.appspot.com",
  messagingSenderId: "20008087886",
  appId: "1:20008087886:web:74f99f185d9be93fdb6e1f",
  measurementId: "G-ZCD40CJXSN",
};

// init firebase
firebase.initializeApp(firebaseConfig);

// init services
const projectFirestore = firebase.firestore();
const projectAuth = firebase.auth();
const projectStorage = firebase.storage();

// timestamp
const timestamp = firebase.firestore.Timestamp;

export { projectFirestore, projectAuth, timestamp, projectStorage };
