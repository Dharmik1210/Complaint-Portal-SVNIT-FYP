import { Link, useParams, useNavigate } from 'react-router-dom';
import { useDocument } from '../../hooks/useDocument';
import { useAuthContext } from '../../hooks/useAuthContext';
import { useFirestore } from '../../hooks/useFirestore';
import { format } from 'date-fns';
import { useState } from 'react';
import { useEffect } from 'react';
import Lightbox from 'react-awesome-lightbox';
import 'react-awesome-lightbox/build/style.css';

// styles
import './Query.css';

export default function Query() {
  const { id } = useParams();
  const { user } = useAuthContext();
  const navigate = useNavigate();
  const [lightboxIsOpen, setLightboxIsOpen] = useState(false);
  const { updateDocument, response: updateRes } = useFirestore('users');
  const { deleteDocument, response: deleteRes } = useFirestore('complaints');
  const { document: complaintDoc, error: complaintError } = useDocument(
    'complaints',
    id
  );
  const { document: userDoc, error: userError } = useDocument(
    'users',
    user.uid
  );
  const [complaint, setComplaint] = useState(null);
  const [userObj, setUserObj] = useState(null);

  // fetch from database
  useEffect(() => {
    if (complaintDoc) {
      setComplaint(complaintDoc);
    }
    if (userDoc) {
      setUserObj(userDoc);
    }
  }, [complaintDoc, userDoc]);

  const openLightbox = () => {
    setLightboxIsOpen(true);
  };

  const closeLightbox = () => {
    setLightboxIsOpen(false);
  };

  const formatDate = (timestamp) => {
    const date = new Date(
      timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000
    );
    const formattedDate = format(date, 'dd-MM-yyyy HH:mm:ss');
    return formattedDate;
  };

  const handleDelete = (e) => {
    e.preventDefault();

    // update user details
    const newUserObj = {
      ...userObj,
      complaints: userObj.complaints.filter(
        (complaint) => complaint.complaintId !== id
      ),
    };
    updateDocument(user.uid, newUserObj);

    // delete from complaints schema
    deleteDocument(id);
    navigate('/');
  };

  return (
    <div>
      {complaint && (
        <div className="query-content">
          <h3>Complaint Details</h3>
          <hr />
          <div className="query">
            <div className="query-summary">
              <ul>
                <li>
                  <span>ID :</span> {complaint.complaintId}
                  <p className="details">
                    Created On {formatDate(complaint.createdAt)}
                  </p>
                </li>
                <li>
                  <span>Type :</span> {complaint.type}
                </li>
                <li>
                  <span>Details:</span> {complaint.details}
                </li>
                <li>
                  <span>Building :</span> {complaint.building}
                </li>
                <li>
                  <span>Exact Location: </span> {complaint.exactLocation}
                </li>
                <li>
                  <span>Raised By:</span>{' '}
                  <Link to={`/profile/${complaint.createdBy.id}`}>
                    {complaint.createdBy.displayName}
                  </Link>
                </li>
              </ul>
            </div>
            {!(updateRes.isPending || deleteRes.isPending) && (
              <button className="btn" onClick={handleDelete}>
                Delete Complaint
              </button>
            )}
            {(updateRes.isPending || deleteRes.isPending) && (
              <button className="btn" disabled>
                Please Wait
              </button>
            )}
          </div>
          <div>
            <img
              className="image"
              src={complaint.photoURL}
              alt={complaint.complaintId}
              onClick={openLightbox}
            />
            {lightboxIsOpen && (
              <Lightbox
                image={complaint.photoURL}
                title={complaint.complaintId}
                onClose={closeLightbox}
              />
            )}
            <center>
              <p>[ Click above image to get better view ]</p>
            </center>
          </div>
        </div>
      )}
      {complaintError && <p className="error">{complaintError}</p>}
      {userError && <p className="error">{userError}</p>}
    </div>
  );
}
